package com.project.sentimentanalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.commons.lang3.ObjectUtils;

public class HomeActivity extends AppCompatActivity implements SensorEventListener {


    private TextView showTemperature;

    // initialze the variables for Ambiant Sensors
    // which is used to find room temperature
    private SensorManager sensorManager;
    private Sensor tempSensor;
    private boolean isTempSensorAvailable; // check the mobile has sensor or not

    EditText name;
    Button proceed;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //hide the title bar of the Activity
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen

        setContentView(R.layout.activity_home);


        name = (EditText)findViewById(R.id.edttxtname);
        proceed= (Button) findViewById(R.id.proceedbtn);
        showTemperature = (TextView) findViewById(R.id.temptxt);
        sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);

        // check whether the android mobile has Ambiant sensor or not
        if(sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)!= null)
        {
            isTempSensorAvailable= true;
            tempSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);


        }
        else
        {
            isTempSensorAvailable=false;
            showTemperature.setText("Temperature sensor is not available");
        }

        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String namestr = name.getText().toString();
                hideKeybaord( v);
                Intent intent = new Intent(HomeActivity.this,MainActivity.class);
                intent.putExtra("name", namestr);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        showTemperature.setText("Temperature is "+ event.values[0] +"C");

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(isTempSensorAvailable)
        {
            sensorManager.registerListener(this,tempSensor,SensorManager.SENSOR_DELAY_NORMAL);
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        if(isTempSensorAvailable)
        {
            sensorManager.unregisterListener(this);
        }
    }

    // this function is used to hide the keyboard when user click on Button
    // Becasue in android the virtual keyboard will not hide automatically
    private void hideKeybaord(View v) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(v.getApplicationWindowToken(),0);
    }
}