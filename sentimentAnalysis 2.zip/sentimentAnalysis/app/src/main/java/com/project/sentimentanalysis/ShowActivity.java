package com.project.sentimentanalysis;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class ShowActivity extends AppCompatActivity {

    TextView txt2, txt3;
    Button again_btn, home_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //hide the title bar of the Activity
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_show);

        txt2 = (TextView) findViewById(R.id.text1);
        txt3 = (TextView) findViewById(R.id.txt3);
        again_btn = (Button) findViewById(R.id.againbtn);
        home_btn = (Button) findViewById(R.id.homebtn);

        String id = getIntent().getStringExtra("sentiment");
        String name = getIntent().getStringExtra("name");
        txt3.setText("Hey "+ name +" ! I am Robo Analyser.....");

        txt2.setText(id);

        again_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ShowActivity.this,MainActivity.class);
                intent.putExtra("name", name);
                startActivity(intent);
                finish();
            }
        });
         home_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ShowActivity.this,HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(ShowActivity.this,HomeActivity.class);
        startActivity(intent);
        finish();
    }


    @Override
    protected void onStart() {
        super.onStart();
        String name = getIntent().getStringExtra("name");
        txt3.setText("Hey "+ name +" ! I am Robo Analyser.....");
    }
}