package com.project.sentimentanalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.DoubleBounce;
import com.github.ybq.android.spinkit.style.FadingCircle;
import com.ibm.cloud.sdk.core.http.ServiceCallback;
import com.ibm.cloud.sdk.core.security.Authenticator;
import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.tone_analyzer.v3.ToneAnalyzer;
import com.ibm.watson.tone_analyzer.v3.model.ToneAnalysis;
import com.ibm.watson.tone_analyzer.v3.model.ToneOptions;
import com.ibm.watson.tone_analyzer.v3.model.ToneScore;

import org.w3c.dom.Text;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView txt1 ;
    EditText edtTxt1;
    Button btn1;
    String sentiment;
    boolean check = true;
    String strname;


    private class AskWatsonTask extends AsyncTask<String,Void,String>{
        @Override
        protected String doInBackground(String... TextToAnalyse) {
            System.out.println(edtTxt1.getText());

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    txt1.setText("Wait I will Analyse your Sentiment!");
                }
            });

             strname = getIntent().getStringExtra("name");
             txt1.setText("Hey "+ strname +" ! I am Robo Analyser.....");


             // Initialize the tone Analyzer App crediatenls (IBM cloud)
            //  link the App with IBM tone analyzer service through API
            //  Intialize the version of service
            Authenticator authenticator = new IamAuthenticator("qOQvdMRiNw5sn9dNH6h0aJXrpRi0nMdzLzhzJYtKvdTs");
            ToneAnalyzer service = new ToneAnalyzer("2017-09-21", authenticator);

            // Now the service will analyse the sentence and return the tones nodes
            ToneOptions toneOptions = new ToneOptions.Builder().text(String.valueOf(edtTxt1.getText())).build();
            ToneAnalysis tone = service.tone(toneOptions).execute().getResult();
            System.out.println(tone);


            sentiment = "Test Sentiment";
            System.out.println(tone);


            try {

                // return the tone id (joy, sadness etc)
                return tone.getDocumentTone().getTones().get(0).getToneId().toString();
            } catch (Exception exception) {

                check= false;
             //   Toast.makeText(getApplicationContext(),"Try Again Robot is confuse",Toast.LENGTH_SHORT).show();
                return null;
            }

        }

       @Override
       protected void onPostExecute(String result) {

            // the if condition check whether the tone has value or not
           //  the result will pass to other Activity through putExtras
           if(check ) {
               Intent intent = new Intent(MainActivity.this, ShowActivity.class);
               intent.putExtra("sentiment", result);
               intent.putExtra("name", strname);
               finish();
               startActivity(intent);
           }

           else
           {
               Toast.makeText(getApplicationContext(),"Try Again Robot is confuse",Toast.LENGTH_SHORT).show();
               Intent intent = new Intent(MainActivity.this,HomeActivity.class);

               startActivity(intent);
               finish();
           }

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txt1 =  (TextView) findViewById(R.id.txt1);
        edtTxt1 =  (EditText) findViewById(R.id.edttxt1);
        btn1 =  (Button) findViewById(R.id.btn1);


     btn1.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             hideKeybaord(v);
             System.out.println("logging to the console that the button pressed for the test" + edtTxt1.getText());
             txt1.setText("Your Analyse setiment is : " +edtTxt1.getText());


             if(TextUtils.isEmpty(edtTxt1.getText().toString()))
             {

                 Toast.makeText(getApplicationContext(),"Write your sentiment......",Toast.LENGTH_LONG).show();


             }
             else
             {
                 // when the sentiement analysis start and call the api the progress bar will start
                 ProgressBar progressBar = (ProgressBar)findViewById(R.id.progress);
                 progressBar.setVisibility(View.VISIBLE);
                 Sprite doubleBounce = new FadingCircle();
                 progressBar.setIndeterminateDrawable(doubleBounce);
                 AskWatsonTask task = new AskWatsonTask();
                 task.execute(new String[]{});

             }
         }
     }

     );
    }

    // this function is used to hide the keyboard when user click on Button
    // Becasue in android the virtual keyboard will not hide automatically
    private void hideKeybaord(View v) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(v.getApplicationWindowToken(),0);
    }

    @Override
    protected void onStart() {
        super.onStart();
        strname = getIntent().getStringExtra("name");
        txt1.setText("Hey "+ strname +" ! I am Robo Analyser.....");

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(MainActivity.this,HomeActivity.class);
        startActivity(intent);
        finish();
    }
}